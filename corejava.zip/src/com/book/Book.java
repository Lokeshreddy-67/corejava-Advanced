package com.book;

import java.util.Scanner;

public class Book {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Book title");
		String booktitle=sc.nextLine();
		
		System.out.println("Enter the Book price");
		int price=sc.nextInt();
		sc.nextLine();
		
		Bookpojo n=new Bookpojo();
		n.setBooktitle(booktitle);
		n.setBookprice(price);
		System.out.println("Book Details");
		System.out.println("Book Title :"+n.getBooktitle());
		System.out.println("Book Price :"+n.getBookprice());
		
	}

}